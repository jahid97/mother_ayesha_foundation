// Featured stories section - Displays a grid of featured stories with read more links
import Link from "next/link"
import { ChevronRight } from "lucide-react"
import { getAllStories } from "@/lib/stories-data"
import StoryCard from "@/components/story-card"

export default function FeaturedStoriesSection() {
  const stories = getAllStories().slice(0, 3)

  return (
    <section className="bg-[#faf6ed] py-16">
      <div className="container mx-auto px-4">
        <div className="mb-10 text-center">
          <h2 className="mb-4 text-3xl font-bold md:text-4xl">Featured Stories</h2>
          <p className="mx-auto max-w-2xl text-lg text-muted-foreground">
            Real stories of hope, resilience, and transformation from the communities we serve.
          </p>
        </div>
        <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-3">
          {stories.map((story) => (
            <StoryCard key={story.id} story={story} />
          ))}
        </div>
        <div className="mt-10 text-center">
          <Link
            href="/stories"
            className="inline-flex items-center rounded-md bg-primary px-6 py-3 text-white hover:bg-primary/90"
          >
            View All Stories
            <ChevronRight className="ml-2 h-4 w-4" />
          </Link>
        </div>
      </div>
    </section>
  )
}

