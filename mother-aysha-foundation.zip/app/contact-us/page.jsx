"use client"

import { useState } from "react"
import { Mail, Phone, MapPin, Clock } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import SiteHeader from "@/components/site-header"
import Footer from "@/components/footer"

export default function ContactPage() {
  // State to track form submission status
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Function to handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault() // Prevent default form submission
    setIsSubmitting(true) // Set submitting state to true
    // Add your form submission logic here
    setTimeout(() => setIsSubmitting(false), 1000) // Reset submitting state after 1 second (simulated)
  }

  return (
    <div className="flex min-h-screen flex-col bg-[#faf6ed]">
      <SiteHeader />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-16 text-center">
          <div className="container mx-auto px-4">
            <h1 className="mb-4 text-4xl font-bold text-[#3d3d3d] md:text-5xl">Contact us</h1>
            <p className="mx-auto max-w-2xl text-[#5a5a5a]">
              Growing up in poverty, children face tough challenges: hunger and malnutrition, limited access to
              education.
            </p>
          </div>
        </section>

        {/* Contact Form and Info Section */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 md:grid-cols-2">
              {/* Contact Information */}
              <div className="space-y-8">
                <div>
                  <h2 className="mb-6 text-2xl font-bold text-[#3d3d3d]">Get in Touch</h2>
                  <p className="text-[#5a5a5a]">
                    Have questions about how you can help? We'd love to hear from you. Send us a message and we'll
                    respond as soon as possible.
                  </p>
                </div>

                <div className="space-y-4">
                  {/* Location */}
                  <div className="flex items-start">
                    <MapPin className="mr-4 h-6 w-6 text-[#4db6ac]" />
                    <div>
                      <h3 className="font-medium text-[#3d3d3d]">Our Location</h3>
                      <p className="text-[#5a5a5a]">123 Charity Lane, Compassion City, NY 10001</p>
                    </div>
                  </div>

                  {/* Phone */}
                  <div className="flex items-start">
                    <Phone className="mr-4 h-6 w-6 text-[#4db6ac]" />
                    <div>
                      <h3 className="font-medium text-[#3d3d3d]">Phone Number</h3>
                      <p className="text-[#5a5a5a]">+1 (555) 123-4567</p>
                    </div>
                  </div>

                  {/* Email */}
                  <div className="flex items-start">
                    <Mail className="mr-4 h-6 w-6 text-[#4db6ac]" />
                    <div>
                      <h3 className="font-medium text-[#3d3d3d]">Email Address</h3>
                      <p className="text-[#5a5a5a]">info@motheraysha.org</p>
                    </div>
                  </div>

                  {/* Working Hours */}
                  <div className="flex items-start">
                    <Clock className="mr-4 h-6 w-6 text-[#4db6ac]" />
                    <div>
                      <h3 className="font-medium text-[#3d3d3d]">Working Hours</h3>
                      <p className="text-[#5a5a5a]">Monday - Friday: 9:00 AM - 6:00 PM</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Contact Form */}
              <div className="rounded-lg bg-white p-8 shadow-lg">
                <form onSubmit={handleSubmit} className="space-y-6">
                  {/* Name input */}
                  <div>
                    <Input
                      type="text"
                      placeholder="Your name *"
                      required
                      className="border-gray-200 focus:border-[#4db6ac]"
                    />
                  </div>

                  {/* Email input */}
                  <div>
                    <Input
                      type="email"
                      placeholder="Email *"
                      required
                      className="border-gray-200 focus:border-[#4db6ac]"
                    />
                  </div>

                  {/* Message textarea */}
                  <div>
                    <Textarea
                      placeholder="Your message *"
                      required
                      className="min-h-[150px] border-gray-200 focus:border-[#4db6ac]"
                    />
                  </div>

                  {/* Submit button */}
                  <Button
                    type="submit"
                    className="w-full bg-[#4db6ac] text-white hover:bg-[#3d9d93]"
                    disabled={isSubmitting}
                  >
                    {isSubmitting ? "Sending..." : "Send Message"}
                  </Button>
                </form>
              </div>
            </div>
          </div>
        </section>

        {/* Map Section */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="overflow-hidden rounded-lg">
              {/* Google Maps iframe */}
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d193595.15830869428!2d-74.119763973046!3d40.69766374874431!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x89c24fa5d33f083b%3A0xc80b8f06e177fe62!2sNew%20York%2C%20NY%2C%20USA!5e0!3m2!1sen!2s!4v1645564756836!5m2!1sen!2s"
                width="100%"
                height="450"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Mother Aysha Foundation Location"
              ></iframe>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

