import Image from "next/image"

export default function PageHero({
  title,
  description,
  imageSrc = "/placeholder.svg?height=600&width=800&text=Hero+Image",
  imageAlt = "Hero image",
  hasImage = true,
  bgColor = "bg-[#3d3d3d]",
}) {
  return (
    <section className={`relative ${bgColor} py-16`}>
      <div className="container mx-auto px-4">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          <div className="text-white">
            <h1 className="text-4xl md:text-5xl font-bold mb-6">{title}</h1>
            {description && <p className="text-gray-300 text-lg">{description}</p>}
          </div>
          {hasImage && (
            <div className="relative h-[300px] rounded-lg overflow-hidden">
              <Image src={imageSrc || "/placeholder.svg"} alt={imageAlt} fill className="object-cover" />
            </div>
          )}
        </div>
      </div>
    </section>
  )
}

