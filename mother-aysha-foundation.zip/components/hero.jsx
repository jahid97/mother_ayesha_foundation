"use client"

import { useState, useEffect, useRef } from "react"
import Image from "next/image"
import Link from "next/link"

const images = [
  {
    src: "/placeholder.svg?height=500&width=1920&text=Children+Smiling",
    alt: "Children smiling and showing artwork",
  },
  {
    src: "/placeholder.svg?height=500&width=1920&text=Education+Programs",
    alt: "Children in education programs",
  },
  {
    src: "/placeholder.svg?height=500&width=1920&text=Clean+Water+Initiative",
    alt: "Clean water initiative for children",
  },
  {
    src: "/placeholder.svg?height=500&width=1920&text=Medical+Care+Support",
    alt: "Medical care support for orphaned children",
  },
]

export default function Hero() {
  const [currentIndex, setCurrentIndex] = useState(0)
  const [isLoaded, setIsLoaded] = useState(false)
  const intervalRef = useRef(null)
  const currentSlideRef = useRef(0)

  // Delay initialization to prevent ResizeObserver issues
  useEffect(() => {
    const timer = setTimeout(() => {
      setIsLoaded(true)
    }, 300)

    return () => clearTimeout(timer)
  }, [])

  // Set up the slideshow interval after component is loaded
  useEffect(() => {
    // Clear any existing interval
    if (intervalRef.current) {
      clearInterval(intervalRef.current)
    }

    // Set up new interval
    const startInterval = () => {
      intervalRef.current = setInterval(() => {
        setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length)
      }, 5000) // Change slide every 5 seconds
    }

    if (isLoaded) {
      startInterval()
    }

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current)
      }
    }
  }, [isLoaded])

  // Update button visibility based on current slide
  useEffect(() => {
    // This will hide/show buttons based on the current slide
    const heroButtons = document.getElementById("hero-buttons")
    if (heroButtons) {
      heroButtons.style.display = currentIndex === 0 ? "flex" : "none"
    }

    // Update the current slide reference
    currentSlideRef.current = currentIndex
  }, [currentIndex])

  // If not loaded yet, render a placeholder
  if (!isLoaded) {
    return (
      <section className="relative h-[600px] md:h-[700px] bg-gray-200">
        <div className="absolute inset-0 flex items-center justify-center">
          <span className="sr-only">Loading slideshow...</span>
        </div>
      </section>
    )
  }

  return (
    <section className="relative h-[600px] md:h-[700px]">
      <div className="relative w-full h-full">
        {images.map((image, index) => (
          <div
            key={index}
            className={`absolute inset-0 transition-opacity duration-1000 ${
              index === currentIndex ? "opacity-100" : "opacity-0"
            }`}
          >
            <Image
              src={image.src || "/placeholder.svg"}
              alt={image.alt}
              fill
              className="object-cover brightness-75"
              priority={index === 0}
              sizes="100vw"
            />
          </div>
        ))}

        {/* Slide indicators */}
        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 flex space-x-2 z-20">
          {images.map((_, index) => (
            <button
              key={index}
              onClick={() => setCurrentIndex(index)}
              className={`hero-indicator w-2.5 h-2.5 rounded-full transition-colors ${
                index === currentIndex ? "bg-white" : "bg-white/50"
              }`}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>

        {/* Navigation arrows */}
        <button
          className="hero-prev-button absolute left-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white w-10 h-10 rounded-full flex items-center justify-center z-20"
          onClick={() => {
            setCurrentIndex((prevIndex) => (prevIndex - 1 + images.length) % images.length)
            // Reset the interval when manually changing slides
            if (intervalRef.current) {
              clearInterval(intervalRef.current)
              intervalRef.current = setInterval(() => {
                setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length)
              }, 5000)
            }
          }}
          aria-label="Previous slide"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={2}
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
          </svg>
        </button>

        <button
          className="hero-next-button absolute right-4 top-1/2 -translate-y-1/2 bg-black/30 hover:bg-black/50 text-white w-10 h-10 rounded-full flex items-center justify-center z-20"
          onClick={() => {
            setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length)
            // Reset the interval when manually changing slides
            if (intervalRef.current) {
              clearInterval(intervalRef.current)
              intervalRef.current = setInterval(() => {
                setCurrentIndex((prevIndex) => (prevIndex + 1) % images.length)
              }, 5000)
            }
          }}
          aria-label="Next slide"
        >
          <svg
            xmlns="http://www.w3.org/2000/svg"
            fill="none"
            viewBox="0 0 24 24"
            strokeWidth={2}
            stroke="currentColor"
            className="w-6 h-6"
          >
            <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
          </svg>
        </button>
      </div>

      {/* Hero content overlay */}
      <div className="absolute inset-0 flex flex-col items-center justify-center text-center text-white p-4 z-10">
        <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold mb-4 max-w-4xl">
          Empowering Children for a Brighter Tomorrow
        </h1>
        <p className="text-xl md:text-2xl mb-8 max-w-2xl">
          Join us in our mission to provide education, healthcare, and support to orphaned children worldwide.
        </p>
        <div className="flex flex-col sm:flex-row gap-4">
          {/* Only show buttons on the first slide */}
          <div id="hero-buttons" className="flex flex-col sm:flex-row gap-4">
            <Link
              href="/donate"
              className="bg-primary hover:bg-primary/90 text-white font-bold py-3 px-6 rounded-full text-lg transition-colors"
            >
              Donate Now
            </Link>
            <Link
              href="/about-us"
              className="bg-white/20 backdrop-blur-sm hover:bg-white/30 text-white font-bold py-3 px-6 rounded-full text-lg transition-colors border border-white/40"
            >
              Learn More
            </Link>
          </div>
        </div>
      </div>
    </section>
  )
}

