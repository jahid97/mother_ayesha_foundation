import { Inter } from "next/font/google"
import "./globals.css"
import ScrollToTop from "@/components/scroll-to-top"
import ChatHelp from "@/components/chat-help"
import InitialLoading from "@/components/initial-loading"

const inter = Inter({ subsets: ["latin"] })

export const metadata = {
  title: "Mother Aysha Foundation",
  description: "Providing care, education, and hope to orphaned children around the world.",
    generator: 'v0.dev'
}

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <InitialLoading />
        <ScrollToTop />
        {children}
        <ChatHelp />
      </body>
    </html>
  )
}



import './globals.css'