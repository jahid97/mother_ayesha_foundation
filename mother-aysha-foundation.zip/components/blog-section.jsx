import Image from "next/image"
import Link from "next/link"
import { Card, CardContent } from "@/components/ui/card"
import { getFeaturedBlogPosts } from "@/lib/blog-data"
import { Button } from "@/components/ui/button"

export default function BlogSection() {
  const featuredPosts = getFeaturedBlogPosts(3)

  return (
    <section className="py-16 bg-[#faf6ed]">
      <div className="container mx-auto px-4">
        <div className="flex justify-between items-center mb-8">
          <div>
            <span className="text-[#4db6ac] font-medium">Blogs</span>
            <h2 className="text-3xl font-bold text-[#3d3d3d]">
              Stories, Insights, And
              <br />
              Updates About Our Mission
            </h2>
            <p className="text-[#5a5a5a] mt-2 max-w-2xl">
              Heartwarming stories highlighting Mother Aysha's impact on children's lives and communities around the
              world.
            </p>
          </div>
          <Link href="/blog" className="hidden md:block">
            <Button variant="outline" className="border-[#4db6ac] text-[#4db6ac] hover:bg-[#4db6ac] hover:text-white">
              View All
            </Button>
          </Link>
        </div>

        <div className="grid md:grid-cols-3 gap-8">
          {featuredPosts.map((post, index) => (
            <Link href={`/blog/${post.slug}`} key={index} className="block">
              <Card className="bg-white border-none shadow-md overflow-hidden hover:shadow-xl transition-shadow">
                <div className="h-48 relative">
                  <Image src={post.image || "/placeholder.svg"} alt={post.title} fill className="object-cover" />
                </div>
                <CardContent className="p-6">
                  <p className="text-sm text-[#5a5a5a] mb-2">{post.date}</p>
                  <h3 className="text-xl font-bold mb-2">{post.title}</h3>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <div className="text-center mt-8 md:hidden">
          <Link href="/blog">
            <Button variant="outline" className="border-[#4db6ac] text-[#4db6ac] hover:bg-[#4db6ac] hover:text-white">
              View All
            </Button>
          </Link>
        </div>
      </div>
    </section>
  )
}

