import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import SiteHeader from "@/components/site-header"
import Footer from "@/components/footer"
import { Check, Calendar, Users, Heart, Award, ArrowRight, Quote } from "lucide-react"
import PartnersDisplay from "@/components/partners-display"
import ImpactStats from "@/components/impact-stats"
import ScrollToSection from "./scroll-to-section"

// Leadership team data
const leadershipTeam = [
  {
    name: "Dr. Amina Rahman",
    role: "Founder & Executive Director",
    bio: "With over 20 years of experience in humanitarian work, Dr. Rahman founded Mother Aysha Foundation with a vision to transform the lives of orphaned children worldwide.",
    image: "/placeholder.svg?height=300&width=300&text=Dr.+Amina",
  },
  {
    name: "Michael Chen",
    role: "Director of Operations",
    bio: "Michael oversees the foundation's global operations, ensuring that our programs are effectively implemented and resources are efficiently allocated.",
    image: "/placeholder.svg?height=300&width=300&text=Michael",
  },
  {
    name: "Sarah Johnson",
    role: "Director of Programs",
    bio: "Sarah develops and manages our educational and healthcare initiatives, focusing on creating sustainable impact in the communities we serve.",
    image: "/placeholder.svg?height=300&width=300&text=Sarah",
  },
]

// Key volunteers
const volunteers = [
  {
    name: "Ali Akbar",
    role: "Volunteer Coordinator",
    image: "/placeholder.svg?height=300&width=300&text=Ali",
  },
  {
    name: "Ethan Patel",
    role: "Fundraising Ambassador",
    image: "/placeholder.svg?height=300&width=300&text=Ethan",
  },
  {
    name: "Julienne Lee",
    role: "Mentorship Program Lead",
    image: "/placeholder.svg?height=300&width=300&text=Julienne",
  },
  {
    name: "Abrar Ahamed",
    role: "Community Outreach Volunteer",
    image: "/placeholder.svg?height=300&width=300&text=Abrar",
  },
]

// Timeline data
const timeline = [
  {
    year: "1998",
    title: "Foundation Established",
    description: "Mother Aysha Foundation was established with a mission to support orphaned children worldwide.",
  },
  {
    year: "2005",
    title: "First School Built",
    description: "Completed construction of our first school, providing education to 250 children.",
  },
  {
    year: "2010",
    title: "Healthcare Initiative",
    description: "Launched our healthcare program, providing medical services to underserved communities.",
  },
  {
    year: "2015",
    title: "Global Expansion",
    description: "Expanded operations to 15 countries, reaching thousands more children in need.",
  },
  {
    year: "2020",
    title: "Digital Education",
    description: "Introduced digital learning programs to bridge the educational gap during global challenges.",
  },
  {
    year: "2023",
    title: "25th Anniversary",
    description: "Celebrated 25 years of service with the launch of our most ambitious projects yet.",
  },
]

// Values data
const values = [
  {
    title: "Compassion",
    description:
      "We approach our work with empathy and understanding, recognizing the dignity of every child we serve.",
    icon: Heart,
  },
  {
    title: "Integrity",
    description:
      "We maintain the highest ethical standards in all our operations, ensuring transparency and accountability.",
    icon: Check,
  },
  {
    title: "Innovation",
    description: "We continuously seek creative solutions to address the complex challenges facing orphaned children.",
    icon: Award,
  },
  {
    title: "Community",
    description: "We believe in the power of community involvement and collaboration to create lasting change.",
    icon: Users,
  },
]

// Testimonials
const testimonials = [
  {
    quote:
      "The Mother Aysha Foundation transformed my life. Their support gave me access to education I never thought possible, and now I'm pursuing my dream of becoming a doctor.",
    name: "Fatima K.",
    role: "Former Beneficiary, Medical Student",
    image: "/placeholder.svg?height=100&width=100&text=Fatima",
  },
  {
    quote:
      "Working with Mother Aysha Foundation has been incredibly rewarding. Their commitment to creating sustainable change and empowering communities is truly inspiring.",
    name: "Dr. James Wilson",
    role: "Partner Organization, Global Health Initiative",
    image: "/placeholder.svg?height=100&width=100&text=James",
  },
]

export default function AboutUsPage() {
  const impactStats = [
    { value: "20+", label: "Countries Impacted", color: "text-[#ff4d4d]" },
    { value: "3 million+", label: "People Served", color: "text-[#4db6ac]" },
    { value: "10million+", label: "Family Lives Changed", color: "text-[#ffa726]" },
    { value: "35+", label: "Projects", color: "text-[#9c27b0]" },
  ]

  return (
    <div className="flex min-h-screen flex-col bg-[#faf6ed]">
      <SiteHeader />
      <ScrollToSection /> {/* Component for smooth scrolling to sections */}
      <main className="flex-grow">
        {/* Hero Section */}
        <section className="relative py-20 overflow-hidden">
          <div className="absolute inset-0 opacity-10">
            <Image
              src="/placeholder.svg?height=1000&width=2000&text=Pattern"
              alt="Background pattern"
              fill
              className="object-cover"
            />
          </div>
          <div className="container mx-auto px-4 relative">
            <div className="max-w-3xl">
              <span className="inline-block bg-[#4db6ac]/10 px-4 py-1 rounded-full text-[#4db6ac] font-medium text-sm mb-4">
                About Us
              </span>
              <h1 className="mb-6 text-4xl font-bold text-[#3d3d3d] md:text-5xl leading-tight">
                Empowering Orphaned Children
                <span className="block text-[#4db6ac]">For a Brighter Future</span>
              </h1>
              <p className="text-lg text-[#5a5a5a] mb-8">
                For over 25 years, Mother Aysha Foundation has been dedicated to providing care, education, and hope to
                orphaned children around the world. Our mission is to create lasting change by addressing the root
                causes of vulnerability and building pathways to self-sufficiency.
              </p>
              <div className="flex flex-wrap gap-4">
                <Link href="/donate">
                  <Button className="bg-[#4db6ac] hover:bg-[#3d9d93] text-white">Support Our Mission</Button>
                </Link>
                <Link href="/volunteer-registration">
                  <Button
                    variant="outline"
                    className="border-[#4db6ac] text-[#4db6ac] hover:bg-[#4db6ac] hover:text-white"
                  >
                    Join Our Team
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>

        {/* Impact Statistics Sectionn */}
        <ImpactStats
          title="Our Global Impact"
          description="Through the generosity of our donors and the dedication of our volunteers, we've made a significant difference in the lives of orphaned children worldwide."
          stats={impactStats}
        />

        {/* Mission & Vision Section */}
        <section id="our-mission" className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 gap-12 items-center">
              <div className="order-2 md:order-1">
                <div className="relative h-[500px] rounded-lg overflow-hidden shadow-xl">
                  <Image
                    src="/placeholder.svg?height=1000&width=800&text=Our+Mission"
                    alt="Children in a classroom"
                    fill
                    className="object-cover"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent flex items-end">
                    <div className="p-6 text-white">
                      <blockquote className="italic text-lg">
                        "Every child deserves love, care, and the opportunity to reach their full potential."
                      </blockquote>
                    </div>
                  </div>
                </div>
              </div>
              <div className="order-1 md:order-2">
                <span className="text-[#4db6ac] font-medium">OUR PURPOSE</span>
                <h2 className="text-3xl font-bold text-[#3d3d3d] mb-6">Our Mission & Vision</h2>

                <div className="mb-8">
                  <h3 className="text-xl font-bold text-[#3d3d3d] mb-3">Mission</h3>
                  <p className="text-[#5a5a5a] mb-4">
                    To provide comprehensive support to orphaned children worldwide through education, healthcare,
                    nutrition, and emotional care, empowering them to overcome adversity and build fulfilling lives.
                  </p>
                </div>

                <div className="mb-8">
                  <h3 className="text-xl font-bold text-[#3d3d3d] mb-3">Vision</h3>
                  <p className="text-[#5a5a5a] mb-4">
                    A world where every orphaned child has access to the care, resources, and opportunities they need to
                    thrive and contribute positively to society.
                  </p>
                </div>

                <div>
                  <h3 className="text-xl font-bold text-[#3d3d3d] mb-3">Our Approach</h3>
                  <p className="text-[#5a5a5a] mb-4">
                    We believe in sustainable, community-based solutions that address both immediate needs and long-term
                    development. By working closely with local partners and involving the communities we serve, we
                    create lasting impact that continues beyond our direct involvement.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Our Values Section */}
        <section className="py-16 bg-[#faf6ed]">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block bg-[#4db6ac]/10 px-4 py-1 rounded-full text-[#4db6ac] font-medium text-sm mb-4">
                OUR GUIDING PRINCIPLES
              </span>
              <h2 className="text-3xl font-bold text-[#3d3d3d] mb-4">Our Core Values</h2>
              <p className="text-[#5a5a5a] max-w-2xl mx-auto">
                These principles guide our work and define our organizational culture, ensuring we remain focused on our
                mission and true to our purpose.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
              {values.map((value, index) => (
                <div key={index} className="bg-white p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                  <div className="w-12 h-12 bg-[#4db6ac]/10 rounded-full flex items-center justify-center mb-4">
                    <value.icon className="h-6 w-6 text-[#4db6ac]" />
                  </div>
                  <h3 className="text-xl font-bold text-[#3d3d3d] mb-2">{value.title}</h3>
                  <p className="text-[#5a5a5a]">{value.description}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Our Programs Section */}
        <section id="our-programs" className="py-16 bg-[#3d3d3d] text-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block bg-white/10 px-4 py-1 rounded-full text-[#4db6ac] font-medium text-sm mb-4">
                OUR INITIATIVES
              </span>
              <h2 className="text-3xl font-bold mb-4">Our Programs</h2>
              <p className="text-gray-300 max-w-2xl mx-auto">
                We run a variety of programs designed to address the unique needs of orphaned children and provide them
                with the support they need to thrive.
              </p>
            </div>

            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Education Program */}
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 hover:bg-white/10 transition-colors">
                <div className="w-14 h-14 bg-[#4db6ac]/20 rounded-full flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#4db6ac]"
                  >
                    <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-3">Education For All</h3>
                <p className="text-gray-300 mb-4">
                  We provide quality education to orphaned children through school construction, teacher training,
                  scholarships, and educational materials.
                </p>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>School construction and renovation</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Teacher training and development</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Scholarships for higher education</span>
                  </li>
                </ul>
              </div>

              {/* Healthcare Program */}
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 hover:bg-white/10 transition-colors">
                <div className="w-14 h-14 bg-[#4db6ac]/20 rounded-full flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#4db6ac]"
                  >
                    <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-3">Healthcare Outreach</h3>
                <p className="text-gray-300 mb-4">
                  We ensure orphaned children have access to essential healthcare services, including preventive care,
                  treatment, and health education.
                </p>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Mobile health clinics</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Vaccination campaigns</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Health education workshops</span>
                  </li>
                </ul>
              </div>

              {/* Nutrition Program */}
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 hover:bg-white/10 transition-colors">
                <div className="w-14 h-14 bg-[#4db6ac]/20 rounded-full flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#4db6ac]"
                  >
                    <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
                    <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
                    <line x1="6" y1="1" x2="6" y2="4"></line>
                    <line x1="10" y1="1" x2="10" y2="4"></line>
                    <line x1="14" y1="1" x2="14" y2="4"></line>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-3">Nutrition Program</h3>
                <p className="text-gray-300 mb-4">
                  We combat malnutrition through sustainable food solutions, meal programs, and nutrition education for
                  orphaned children.
                </p>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Daily meal programs</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Community gardens at orphanages</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Nutrition education for caregivers</span>
                  </li>
                </ul>
              </div>

              {/* Safe Shelter Program */}
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 hover:bg-white/10 transition-colors">
                <div className="w-14 h-14 bg-[#4db6ac]/20 rounded-full flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#4db6ac]"
                  >
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                    <polyline points="9 22 9 12 15 12 15 22"></polyline>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-3">Safe Shelter Program</h3>
                <p className="text-gray-300 mb-4">
                  We build and renovate orphanages and group homes to provide safe, nurturing environments for children
                  who have lost their parents.
                </p>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Orphanage construction and renovation</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Safety and security systems</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Comfortable living environments</span>
                  </li>
                </ul>
              </div>

              {/* Mental Health Support */}
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 hover:bg-white/10 transition-colors">
                <div className="w-14 h-14 bg-[#4db6ac]/20 rounded-full flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#4db6ac]"
                  >
                    <circle cx="12" cy="12" r="10"></circle>
                    <path d="M12 16v-4"></path>
                    <path d="M12 8h.01"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-3">Mental Health Support</h3>
                <p className="text-gray-300 mb-4">
                  We provide psychological support and counseling services to help orphaned children cope with trauma
                  and build emotional resilience.
                </p>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Individual and group counseling</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Trauma-informed care training</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Art and play therapy</span>
                  </li>
                </ul>
              </div>

              {/* Vocational Training */}
              <div className="bg-white/5 backdrop-blur-sm rounded-lg p-6 hover:bg-white/10 transition-colors">
                <div className="w-14 h-14 bg-[#4db6ac]/20 rounded-full flex items-center justify-center mb-4">
                  <svg
                    xmlns="http://www.w3.org/2000/svg"
                    width="24"
                    height="24"
                    viewBox="0 0 24 24"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                    className="text-[#4db6ac]"
                  >
                    <path d="M2 3h6a4 4 0 0 1 4 4v14a3 3 0 0 0-3-3H2z"></path>
                    <path d="M22 3h-6a4 4 0 0 0-4 4v14a3 3 0 0 1 3-3h7z"></path>
                  </svg>
                </div>
                <h3 className="text-xl font-bold mb-3">Vocational Training</h3>
                <p className="text-gray-300 mb-4">
                  We equip older orphaned children with practical skills for employment and self-sufficiency through
                  vocational training centers.
                </p>
                <ul className="space-y-2 text-gray-300">
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Skills training in various trades</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Business development education</span>
                  </li>
                  <li className="flex items-start">
                    <span className="text-[#4db6ac] mr-2">•</span>
                    <span>Apprenticeship opportunities</span>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </section>

        {/* Our History Timeline Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block bg-[#4db6ac]/10 px-4 py-1 rounded-full text-[#4db6ac] font-medium text-sm mb-4">
                OUR JOURNEY
              </span>
              <h2 className="text-3xl font-bold text-[#3d3d3d] mb-4">Our History</h2>
              <p className="text-[#5a5a5a] max-w-2xl mx-auto">
                From humble beginnings to global impact, our journey has been defined by dedication, growth, and
                unwavering commitment to our mission.
              </p>
            </div>

            <div className="relative">
              {/* Timeline line */}
              <div className="absolute left-1/2 transform -translate-x-1/2 h-full w-1 bg-[#4db6ac]/20 hidden md:block"></div>

              <div className="space-y-12">
                {timeline.map((item, index) => (
                  <div key={index} className="relative">
                    {/* Timeline dot */}
                    <div className="absolute left-1/2 transform -translate-x-1/2 w-6 h-6 rounded-full bg-[#4db6ac] border-4 border-white hidden md:block"></div>

                    <div className={`md:w-1/2 ${index % 2 === 0 ? "md:pr-12 md:ml-auto" : "md:pl-12"}`}>
                      <div className="bg-[#faf6ed] p-6 rounded-lg shadow-md hover:shadow-lg transition-shadow">
                        <div className="flex items-center mb-3">
                          <Calendar className="h-5 w-5 text-[#4db6ac] mr-2" />
                          <span className="text-[#4db6ac] font-bold">{item.year}</span>
                        </div>
                        <h3 className="text-xl font-bold text-[#3d3d3d] mb-2">{item.title}</h3>
                        <p className="text-[#5a5a5a]">{item.description}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </section>

        {/* Leadership Team Section */}
        <section className="py-16 bg-[#faf6ed]">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block bg-[#4db6ac]/10 px-4 py-1 rounded-full text-[#4db6ac] font-medium text-sm mb-4">
                OUR LEADERSHIP
              </span>
              <h2 className="text-3xl font-bold text-[#3d3d3d] mb-4">Meet Our Leadership Team</h2>
              <p className="text-[#5a5a5a] max-w-2xl mx-auto">
                Our dedicated leadership team brings diverse expertise and a shared passion for our mission.
              </p>
            </div>

            <div className="grid md:grid-cols-3 gap-8">
              {leadershipTeam.map((leader, index) => (
                <div
                  key={index}
                  className="bg-white rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-all"
                >
                  <div className="relative h-64">
                    <Image src={leader.image || "/placeholder.svg"} alt={leader.name} fill className="object-cover" />
                  </div>
                  <div className="p-6">
                    <h3 className="text-xl font-bold text-[#3d3d3d] mb-1">{leader.name}</h3>
                    <p className="text-[#4db6ac] font-medium mb-3">{leader.role}</p>
                    <p className="text-[#5a5a5a]">{leader.bio}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Testimonials Section */}
        <section className="py-16 bg-[#3d3d3d] text-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block bg-white/10 px-4 py-1 rounded-full text-[#4db6ac] font-medium text-sm mb-4">
                TESTIMONIALS
              </span>
              <h2 className="text-3xl font-bold mb-4">Voices of Impact</h2>
              <p className="text-gray-300 max-w-2xl mx-auto">
                Hear from those whose lives have been touched by our work.
              </p>
            </div>

            <div className="grid md:grid-cols-2 gap-8">
              {testimonials.map((testimonial, index) => (
                <div key={index} className="bg-white/5 backdrop-blur-sm p-6 rounded-lg">
                  <div className="flex items-start mb-4">
                    <Quote className="h-8 w-8 text-[#4db6ac] mr-4 flex-shrink-0" />
                    <p className="italic text-gray-300">{testimonial.quote}</p>
                  </div>
                  <div className="flex items-center">
                    <div className="relative h-12 w-12 rounded-full overflow-hidden mr-4">
                      <Image
                        src={testimonial.image || "/placeholder.svg"}
                        alt={testimonial.name}
                        fill
                        className="object-cover"
                      />
                    </div>
                    <div>
                      <p className="font-bold">{testimonial.name}</p>
                      <p className="text-sm text-gray-300">{testimonial.role}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Volunteer Section */}
        <section className="py-16 bg-white">
          <div className="container mx-auto px-4">
            <div className="text-center mb-12">
              <span className="inline-block bg-[#4db6ac]/10 px-4 py-1 rounded-full text-[#4db6ac] font-medium text-sm mb-4">
                OUR TEAM
              </span>
              <h2 className="text-3xl font-bold text-[#3d3d3d] mb-4">Our Dedicated Volunteers</h2>
              <p className="text-[#5a5a5a] max-w-2xl mx-auto">
                Meet some of the incredible volunteers who make our work possible through their time, skills, and
                passion.
              </p>
            </div>

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
              {volunteers.map((volunteer, index) => (
                <div key={index} className="group relative overflow-hidden rounded-lg">
                  <div className="aspect-square relative">
                    <Image
                      src={volunteer.image || "/placeholder.svg"}
                      alt={volunteer.name}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-110"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100">
                      <div className="absolute bottom-0 w-full p-4 text-white">
                        <h3 className="text-lg font-bold">{volunteer.name}</h3>
                        <p className="text-[#4db6ac]">{volunteer.role}</p>
                      </div>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            <div className="text-center mt-10">
              <Link href="/volunteer-registration">
                <Button className="bg-[#4db6ac] hover:bg-[#3d9d93] text-white">
                  Become a Volunteer
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Partners Section */}
        <PartnersDisplay className="bg-[#faf6ed" />

        {/* Call to Action Section */}
        <section className="py-16 bg-[#3d3d3d] text-white">
          <div className="container mx-auto px-4 text-center">
            <h2 className="text-3xl font-bold mb-6">Join Us in Making a Difference</h2>
            <p className="text-gray-300 mb-8 max-w-2xl mx-auto">
              Together, we can create a world where every orphaned child has the opportunity to thrive. Your support
              makes our work possible.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link href="/donate">
                <Button className="bg-[#4db6ac] hover:bg-[#3d9d93] text-white px-8 py-3 text-lg">Donate Now</Button>
              </Link>
              <Link href="/contact-us">
                <Button variant="outline" className="border-white text-white hover:bg-white/10 px-8 py-3 text-lg">
                  Contact Us
                </Button>
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </div>
  )
}

