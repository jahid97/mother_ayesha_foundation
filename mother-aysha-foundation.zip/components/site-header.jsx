/**
 * Site Header Component
 *
 * This component provides the main navigation for the Mother Aysha Foundation website.
 * Features include:
 * - Responsive design with mobile menu
 * - Language selector
 * - User account dropdown
 * - Donation button
 * - Search functionality
 *
 * The header changes appearance on scroll for better user experience.
 */
"use client"
import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { Search, Menu, X, User, Globe, LogIn, UserPlus, Settings, HelpCircle } from "lucide-react"

export default function SiteHeader() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const [currentLanguage, setCurrentLanguage] = useState("EN")

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 10)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [])

  useEffect(() => {
    const handleClickOutside = (event) => {
      const target = event.target
      if (
        isMobileMenuOpen &&
        !target.closest('button[aria-label="Additional Menu"]') &&
        !target.closest('div[class*="absolute right-4"]')
      ) {
        setIsMobileMenuOpen(false)
      }
    }

    document.addEventListener("click", handleClickOutside)
    return () => document.removeEventListener("click", handleClickOutside)
  }, [isMobileMenuOpen])

  const languages = [
    { code: "EN", name: "English" },
    { code: "FR", name: "Français" },
    { code: "AR", name: "العربية" },
    { code: "ES", name: "Español" },
  ]

  return (
    <header
      className={cn(
        "sticky top-0 z-50 w-full transition-all duration-300",
        isScrolled ? "bg-[#3d3d3d]/95 backdrop-blur-sm shadow-md py-2" : "bg-[#3d3d3d] py-3",
      )}
    >
      <div className="container mx-auto px-4">
        <div className="flex items-center justify-between">
          {/* Logo */}
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-3">
              <div className="relative w-10 h-10 rounded-full overflow-hidden bg-[#4db6ac]">
                <Image
                  src="/placeholder.svg?height=40&width=40&text=MA"
                  alt="Mother Aysha Foundation Logo"
                  width={40}
                  height={40}
                  className="object-cover"
                />
              </div>
              <div>
                <h1 className="text-xl font-bold text-white leading-tight">Mother Aysha Foundation</h1>
              </div>
            </Link>
          </div>

          {/* Desktop Navigation - Basic Links Upfront */}
          <div className="hidden lg:flex items-center space-x-4">
            {/* Basic Navigation Links */}
            <nav className="flex items-center space-x-1">
              <Link href="/" className="px-3 py-2 text-white hover:text-[#4db6ac] transition-colors">
                Home
              </Link>
              <Link href="/about-us" className="px-3 py-2 text-white hover:text-[#4db6ac] transition-colors">
                About
              </Link>
              <Link href="/stories" className="px-3 py-2 text-white hover:text-[#4db6ac] transition-colors">
                Stories
              </Link>
              <Link href="/projects" className="px-3 py-2 text-white hover:text-[#4db6ac] transition-colors">
                Projects
              </Link>
              <Link href="/gallery" className="px-3 py-2 text-white hover:text-[#4db6ac] transition-colors">
                Gallery
              </Link>
              <Link href="/contact-us" className="px-3 py-2 text-white hover:text-[#4db6ac] transition-colors">
                Contact
              </Link>
            </nav>

            {/* Language Selector */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-9 px-2 text-white hover:bg-white/10">
                  <Globe className="h-4 w-4 mr-1" />
                  <span>{currentLanguage}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40 bg-white">
                <DropdownMenuLabel>Select Language</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {languages.map((lang) => (
                  <DropdownMenuItem
                    key={lang.code}
                    className={cn("cursor-pointer", currentLanguage === lang.code && "bg-muted")}
                    onClick={() => setCurrentLanguage(lang.code)}
                  >
                    {lang.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User Account */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-9 w-9 rounded-full text-white hover:bg-white/10">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-white">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <Link href="/login" className="w-full">
                  <DropdownMenuItem className="cursor-pointer">
                    <LogIn className="mr-2 h-4 w-4" />
                    <span>Sign In</span>
                  </DropdownMenuItem>
                </Link>
                <Link href="/signup" className="w-full">
                  <DropdownMenuItem className="cursor-pointer">
                    <UserPlus className="mr-2 h-4 w-4" />
                    <span>Register</span>
                  </DropdownMenuItem>
                </Link>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Account Settings</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <HelpCircle className="mr-2 h-4 w-4" />
                  <span>Help & Support</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <div className="flex items-center space-x-2 ml-2">
              <Link href="/donate">
                <Button className="bg-[#4db6ac] hover:bg-[#3d9d93] text-white">Donate</Button>
              </Link>

              {/* Menu for Additional Links */}
              <Button
                variant="ghost"
                size="icon"
                className="text-white hover:bg-white/10"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                aria-label="Additional Menu"
              >
                <Menu className="h-5 w-5" />
              </Button>
            </div>
          </div>

          {/* Mobile Menu Button */}
          <div className="flex items-center lg:hidden space-x-2">
            {/* Language Selector - Mobile */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="sm" className="h-9 px-2 text-white hover:bg-white/10">
                  <Globe className="h-4 w-4" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40 bg-white">
                <DropdownMenuLabel>Select Language</DropdownMenuLabel>
                <DropdownMenuSeparator />
                {languages.map((lang) => (
                  <DropdownMenuItem
                    key={lang.code}
                    className={cn("cursor-pointer", currentLanguage === lang.code && "bg-muted")}
                    onClick={() => setCurrentLanguage(lang.code)}
                  >
                    {lang.name}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            {/* User Account - Mobile */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="h-9 w-9 text-white hover:bg-white/10">
                  <User className="h-5 w-5" />
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-white">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <Link href="/login" className="w-full">
                  <DropdownMenuItem className="cursor-pointer">
                    <LogIn className="mr-2 h-4 w-4" />
                    <span>Sign In</span>
                  </DropdownMenuItem>
                </Link>
                <Link href="/signup" className="w-full">
                  <DropdownMenuItem className="cursor-pointer">
                    <UserPlus className="mr-2 h-4 w-4" />
                    <span>Register</span>
                  </DropdownMenuItem>
                </Link>
                <DropdownMenuSeparator />
                <DropdownMenuItem className="cursor-pointer">
                  <Settings className="mr-2 h-4 w-4" />
                  <span>Account Settings</span>
                </DropdownMenuItem>
                <DropdownMenuItem className="cursor-pointer">
                  <HelpCircle className="mr-2 h-4 w-4" />
                  <span>Help & Support</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Link href="/donate">
              <Button className="bg-[#4db6ac] hover:bg-[#3d9d93] text-white">Donate</Button>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              className="text-white hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Menu"
            >
              {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div
          className={cn(
            "lg:hidden overflow-hidden transition-all duration-300 ease-in-out",
            isMobileMenuOpen ? "max-h-[500px] opacity-100 mt-4" : "max-h-0 opacity-0",
          )}
        >
          <nav className="flex flex-col space-y-4 py-4">
            <Link
              href="/"
              className="text-white hover:text-[#4db6ac] px-2 py-2 rounded hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Home
            </Link>
            <Link
              href="/about-us"
              className="text-white hover:text-[#4db6ac] px-2 py-2 rounded hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              About
            </Link>
            <Link
              href="/projects"
              className="text-white hover:text-[#4db6ac] px-2 py-2 rounded hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Projects
            </Link>
            <Link
              href="/blog"
              className="text-white hover:text-[#4db6ac] px-2 py-2 rounded hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Blog
            </Link>
            <Link
              href="/gallery"
              className="text-white hover:text-[#4db6ac] px-2 py-2 rounded hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Gallery
            </Link>
            <Link
              href="/volunteer-registration"
              className="text-white hover:text-[#4db6ac] px-2 py-2 rounded hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Volunteer Registration
            </Link>
            <Link
              href="/contact-us"
              className="text-white hover:text-[#4db6ac] px-2 py-2 rounded hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Contact
            </Link>
            <Link
              href="/donate"
              className="text-white hover:text-[#4db6ac] px-2 py-2 rounded hover:bg-white/10"
              onClick={() => setIsMobileMenuOpen(false)}
            >
              Donate
            </Link>

            <div className="relative mt-2 border-t border-white/10 pt-4">
              <Search className="absolute left-3 top-[calc(50%+8px)] transform -translate-y-1/2 h-4 w-4 text-white/70" />
              <input
                type="search"
                placeholder="Search..."
                className="h-10 w-full rounded-md bg-white/10 px-10 text-sm text-white placeholder:text-white/70 focus:outline-none focus:ring-2 focus:ring-[#4db6ac] focus:bg-white/20"
              />
            </div>
          </nav>
        </div>
      </div>

      {/* Desktop Additional Menu */}
      <div
        className={cn(
          "absolute right-4 top-16 w-64 bg-[#3d3d3d] shadow-lg rounded-md overflow-hidden transition-all duration-300 ease-in-out z-50 lg:block hidden",
          isMobileMenuOpen ? "opacity-100 translate-y-0" : "opacity-0 -translate-y-2 pointer-events-none",
        )}
      >
        <nav className="flex flex-col py-2">
          <div className="px-4 py-2 text-[#4db6ac] text-sm font-medium">Additional Links</div>
          <Link
            href="/volunteer-registration"
            className="text-white hover:text-[#4db6ac] px-4 py-2 hover:bg-white/10 block"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Volunteer Registration
          </Link>
          <Link
            href="/blog"
            className="text-white hover:text-[#4db6ac] px-4 py-2 hover:bg-white/10 block"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Blog
          </Link>
          <Link
            href="/team"
            className="text-white hover:text-[#4db6ac] px-4 py-2 hover:bg-white/10 block"
            onClick={() => setIsMobileMenuOpen(false)}
          >
            Our Team
          </Link>
          <div className="border-t border-white/10 mt-2 pt-2 px-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-white/70" />
              <input
                type="search"
                placeholder="Search..."
                className="h-9 w-full rounded-md bg-white/10 pl-10 pr-4 text-sm text-white placeholder:text-white/70 focus:outline-none focus:ring-2 focus:ring-[#4db6ac] focus:bg-white/20"
              />
            </div>
          </div>
        </nav>
      </div>
    </header>
  )
}

