import BlogCard from "@/components/blog-card"
import SiteHeader from "@/components/site-header"
import Footer from "@/components/footer"
import PageHero from "@/components/page-hero"
import PartnersDisplay from "@/components/partners-display"
import { blogPosts } from "@/lib/blog-data"

export default function BlogPage() {
  return (
    <div className="flex flex-col min-h-screen bg-[#faf6ed]">
      {/* Header/Navigation */}
      <SiteHeader />

      <main className="flex-grow">
        {/* Hero Section */}
        <PageHero
          title="Blog & Update"
          description="Inspiring stories and updates from our orphaned children's community, highlighting the impact of your support and generosity. Read about the lives transformed, hopes renewed, and futures brightened through our initiatives and your kindness, and discover the power of compassion in action."
          imageSrc="/placeholder.svg?height=600&width=800&text=Blog"
          imageAlt="Blog header image"
        />

        {/* Blog Posts Grid */}
        <section className="py-16">
          <div className="container mx-auto px-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
              {/* Map through blog posts and render a BlogCard for each */}
              {blogPosts.map((post, index) => (
                <BlogCard key={index} {...post} />
              ))}
            </div>
          </div>
        </section>

        {/* Partners Section */}
        <PartnersDisplay />
      </main>

      {/* Footer */}
      <Footer />
    </div>
  )
}

