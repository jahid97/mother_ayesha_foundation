import Image from "next/image"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import SiteHeader from "@/components/site-header"
import Footer from "@/components/footer"

// Team member data
const teamMembers = [
  {
    name: "Ali Akbar",
    role: "Volunteer Coordinator",
    image: "/placeholder.svg?height=400&width=400&text=Ali",
  },
  {
    name: "Ethan Patel",
    role: "Fundraising Ambassador",
    image: "/placeholder.svg?height=400&width=400&text=Ethan",
  },
  {
    name: "Julianne Lee",
    role: "Mentorship Program Lead",
    image: "/placeholder.svg?height=400&width=400&text=Julianne",
  },
  {
    name: "Abrar Ahamed",
    role: "Community Outreach Volunteer",
    image: "/placeholder.svg?height=400&width=400&text=Abrar",
  },
  {
    name: "Rachel Kim",
    role: "Event Coordinator",
    image: "/placeholder.svg?height=400&width=400&text=Rachel",
  },
  {
    name: "Michael Reyes",
    role: "Mentorship Program Lead",
    image: "/placeholder.svg?height=400&width=400&text=Michael",
  },
  {
    name: "Emily Wong",
    role: "Fundraising Manager",
    image: "/placeholder.svg?height=400&width=400&text=Emily",
  },
  {
    name: "David Lee",
    role: "Community Outreach Specialist",
    image: "/placeholder.svg?height=400&width=400&text=David",
  },
  {
    name: "Olivia Brown",
    role: "Tutoring Program Coordinator",
    image: "/placeholder.svg?height=400&width=400&text=Olivia",
  },
  {
    name: "Christopher Martin",
    role: "Grant Writer",
    image: "/placeholder.svg?height=400&width=400&text=Christopher",
  },
  {
    name: "Samantha Taylor",
    role: "Volunteer Coordinator",
    image: "/placeholder.svg?height=400&width=400&text=Samantha",
  },
  {
    name: "Alexander Hall",
    role: "Youth Program Director",
    image: "/placeholder.svg?height=400&width=400&text=Alexander",
  },
]

export default function TeamPage() {
  return (
    <div className="flex min-h-screen flex-col bg-[#faf6ed]">
      <SiteHeader />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 text-center">
            <h1 className="mb-4 text-4xl font-bold text-[#3d3d3d] md:text-5xl">Our Volunteer</h1>
            <p className="mx-auto mb-12 max-w-2xl text-[#5a5a5a]">
              Meet the dedicated individuals who generously give their time and energy to make a difference in the lives
              of orphaned children.
            </p>
          </div>
        </section>

        {/* Team Grid */}
        <section className="py-12">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4">
              {teamMembers.map((member, index) => (
                <div
                  key={member.name}
                  className="group relative overflow-hidden rounded-lg bg-white shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
                >
                  <div className="aspect-square">
                    <div className="relative h-full w-full overflow-hidden">
                      <Image
                        src={member.image || "/placeholder.svg"}
                        alt={member.name}
                        fill
                        className="object-cover transition-transform duration-500 group-hover:scale-110"
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100"></div>
                    </div>
                  </div>
                  <div className="absolute inset-x-0 bottom-0 p-4 text-white opacity-0 transition-all duration-300 group-hover:opacity-100">
                    <h3 className="text-lg font-bold">{member.name}</h3>
                    <p className="text-sm text-[#4db6ac]">{member.role}</p>
                  </div>
                </div>
              ))}
            </div>

            <div className="mt-12 text-center">
              <Link href="/volunteer-registration">
                <Button className="bg-[#4db6ac] text-white hover:bg-[#3d9d93]">Become a Volunteer</Button>
              </Link>
            </div>
          </div>
        </section>

        {/* Impact Stats */}
        <section className="bg-[#3d3d3d] py-16 text-white">
          <div className="container mx-auto px-4">
            <div className="grid gap-8 text-center sm:grid-cols-2 lg:grid-cols-4">
              <div>
                <h3 className="mb-2 text-4xl font-bold text-[#4db6ac]">100+</h3>
                <p>Active Volunteers</p>
              </div>
              <div>
                <h3 className="mb-2 text-4xl font-bold text-[#4db6ac]">5000+</h3>
                <p>Children Supported</p>
              </div>
              <div>
                <h3 className="mb-2 text-4xl font-bold text-[#4db6ac]">20+</h3>
                <p>Countries Reached</p>
              </div>
              <div>
                <h3 className="mb-2 text-4xl font-bold text-[#4db6ac]">35+</h3>
                <p>Ongoing Projects</p>
              </div>
            </div>
          </div>
        </section>

        {/* Partners Section */}
        <section className="py-16">
          <div className="container mx-auto px-4 text-center">
            <p className="mb-8 text-[#3d3d3d]">
              Over <span className="font-bold text-[#4db6ac]">200+</span> partner currently help us
            </p>
            <div className="flex flex-wrap items-center justify-center gap-8">
              {["Save the Children", "UNICEF", "American Red Cross", "Amazon", "World Vision"].map((partner) => (
                <div key={partner} className="relative h-16 w-32">
                  <Image
                    src={`/placeholder.svg?height=64&width=128&text=${partner.replace(/\s+/g, "+")}`}
                    alt={partner}
                    fill
                    className="object-contain"
                  />
                </div>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  )
}

