/**
 * Footer Component
 *
 * This component provides the site footer for the Mother Aysha Foundation website.
 * It includes:
 * - Organization information and social media links
 * - Quick links to important pages
 * - Contact information
 * - Newsletter subscription
 * - Copyright and policy links
 *
 * The footer appears on all pages of the website for consistent navigation.
 */
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Facebook, Twitter, Instagram, Linkedin, Youtube, Mail, Phone, MapPin, Heart } from "lucide-react"

export function Footer() {
  const currentYear = new Date().getFullYear()

  return (
    <footer className="bg-[#3d3d3d] text-white pt-16 pb-8">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* About Column */}
          <div>
            <div className="flex items-center space-x-3 mb-6">
              <div className="relative w-10 h-10 rounded-full overflow-hidden bg-[#4db6ac]">
                <Image
                  src="/placeholder.svg?height=40&width=40&text=MA"
                  alt="Mother Aysha Foundation Logo"
                  width={40}
                  height={40}
                  className="object-cover"
                />
              </div>
              <h2 className="text-xl font-bold leading-tight">Mother Aysha Foundation</h2>
            </div>

            <p className="text-gray-300 mb-6">
              Dedicated to providing care, education, and hope to orphaned children around the world. Together, we can
              create lasting change.
            </p>

            <div className="flex space-x-3">
              <Link
                href="#"
                aria-label="Facebook"
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-[#4db6ac] transition-colors duration-300"
              >
                <Facebook size={18} />
              </Link>
              <Link
                href="#"
                aria-label="Twitter"
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-[#4db6ac] transition-colors duration-300"
              >
                <Twitter size={18} />
              </Link>
              <Link
                href="#"
                aria-label="Instagram"
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-[#4db6ac] transition-colors duration-300"
              >
                <Instagram size={18} />
              </Link>
              <Link
                href="#"
                aria-label="LinkedIn"
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-[#4db6ac] transition-colors duration-300"
              >
                <Linkedin size={18} />
              </Link>
              <Link
                href="#"
                aria-label="YouTube"
                className="w-9 h-9 flex items-center justify-center rounded-full bg-white/10 hover:bg-[#4db6ac] transition-colors duration-300"
              >
                <Youtube size={18} />
              </Link>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-lg font-bold mb-6 relative inline-block">
              Quick Links
              <span className="absolute -bottom-2 left-0 w-12 h-1 bg-[#4db6ac]"></span>
            </h3>
            <ul className="space-y-3">
              <li>
                <Link
                  href="/about-us"
                  className="text-gray-300 hover:text-[#4db6ac] transition-colors duration-200 flex items-center"
                >
                  <span className="mr-2">›</span> About Us
                </Link>
              </li>
              <li>
                <Link
                  href="/our-causes"
                  className="text-gray-300 hover:text-[#4db6ac] transition-colors duration-200 flex items-center"
                >
                  <span className="mr-2">›</span> Our Causes
                </Link>
              </li>
              <li>
                <Link
                  href="/projects"
                  className="text-gray-300 hover:text-[#4db6ac] transition-colors duration-200 flex items-center"
                >
                  <span className="mr-2">›</span> Projects
                </Link>
              </li>
              <li>
                <Link
                  href="/gallery"
                  className="text-gray-300 hover:text-[#4db6ac] transition-colors duration-200 flex items-center"
                >
                  <span className="mr-2">›</span> Gallery
                </Link>
              </li>
              <li>
                <Link
                  href="/team"
                  className="text-gray-300 hover:text-[#4db6ac] transition-colors duration-200 flex items-center"
                >
                  <span className="mr-2">›</span> Our Team
                </Link>
              </li>
              <li>
                <Link
                  href="/blog"
                  className="text-gray-300 hover:text-[#4db6ac] transition-colors duration-200 flex items-center"
                >
                  <span className="mr-2">›</span> Blog
                </Link>
              </li>
              <li>
                <Link
                  href="/stories"
                  className="text-gray-300 hover:text-[#4db6ac] transition-colors duration-200 flex items-center"
                >
                  <span className="mr-2">›</span> Stories
                </Link>
              </li>
              <li>
                <Link
                  href="/contact-us"
                  className="text-gray-300 hover:text-[#4db6ac] transition-colors duration-200 flex items-center"
                >
                  <span className="mr-2">›</span> Contact Us
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Information */}
          <div>
            <h3 className="text-lg font-bold mb-6 relative inline-block">
              Contact Us
              <span className="absolute -bottom-2 left-0 w-12 h-1 bg-[#4db6ac]"></span>
            </h3>
            <ul className="space-y-4">
              <li className="flex items-start">
                <MapPin className="mr-3 h-5 w-5 text-[#4db6ac] mt-0.5 flex-shrink-0" />
                <span className="text-gray-300">
                  123 Charity Lane, Compassion City
                  <br />
                  New York, NY 10001
                </span>
              </li>
              <li className="flex items-center">
                <Phone className="mr-3 h-5 w-5 text-[#4db6ac] flex-shrink-0" />
                <span className="text-gray-300">+1 (555) 123-4567</span>
              </li>
              <li className="flex items-center">
                <Mail className="mr-3 h-5 w-5 text-[#4db6ac] flex-shrink-0" />
                <span className="text-gray-300">info@motheraysha.org</span>
              </li>
            </ul>

            <div className="mt-6">
              <Link href="/donate">
                <Button className="bg-[#4db6ac] hover:bg-[#3d9d93] text-white">Donate Now</Button>
              </Link>
            </div>
          </div>

          {/* Newsletter */}
          <div>
            <h3 className="text-lg font-bold mb-6 relative inline-block">
              Newsletter
              <span className="absolute -bottom-2 left-0 w-12 h-1 bg-[#4db6ac]"></span>
            </h3>
            <p className="text-gray-300 mb-4">
              Subscribe to our newsletter to receive updates on our work and how you can help.
            </p>

            <div className="space-y-3">
              <Input
                type="email"
                placeholder="Your email address"
                className="bg-white/10 border-white/20 text-white placeholder:text-gray-400 focus:border-[#4db6ac]"
              />
              <Button className="w-full bg-[#4db6ac] hover:bg-[#3d9d93] text-white">Subscribe</Button>
            </div>

            <p className="text-xs text-gray-400 mt-3">
              By subscribing, you agree to our Privacy Policy and consent to receive updates from our organization.
            </p>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-white/10 flex flex-col md:flex-row justify-between items-center">
          <p className="text-gray-400 text-sm mb-4 md:mb-0">
            © {currentYear} Mother Aysha Foundation. All rights reserved.
          </p>

          <div className="flex flex-wrap justify-center gap-4 text-sm text-gray-400">
            <Link href="/privacy-policy" className="hover:text-[#4db6ac] transition-colors">
              Privacy Policy
            </Link>
            <Link href="/terms-of-service" className="hover:text-[#4db6ac] transition-colors">
              Terms of Service
            </Link>
            <Link href="/cookie-policy" className="hover:text-[#4db6ac] transition-colors">
              Cookie Policy
            </Link>
            <div className="flex items-center">
              <span>Made with</span>
              <Heart className="h-3 w-3 mx-1 text-[#4db6ac]" />
              <span>for humanity</span>
            </div>
          </div>
        </div>
      </div>
    </footer>
  )
}

export default Footer

