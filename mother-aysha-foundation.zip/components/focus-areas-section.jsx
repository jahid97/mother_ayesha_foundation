import { Button } from "@/components/ui/button"
import Link from "next/link"

export default function FocusAreasSection() {
  return (
    <section className="bg-[#faf6ed] py-16">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-[#3d3d3d] mb-3">Our Focus Areas</h2>
          <p className="text-[#5a5a5a] max-w-2xl mx-auto">
            We provide comprehensive support to orphaned children through these key areas of focus
          </p>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6 text-center">
          <div className="flex flex-col items-center group">
            <div className="bg-[#f8e8c6] p-5 rounded-full mb-4 group-hover:bg-[#f5d69e] transition-colors duration-300">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-[#e6a23c]"
              >
                <path d="M18 8h1a4 4 0 0 1 0 8h-1"></path>
                <path d="M2 8h16v9a4 4 0 0 1-4 4H6a4 4 0 0 1-4-4V8z"></path>
                <line x1="6" y1="1" x2="6" y2="4"></line>
                <line x1="10" y1="1" x2="10" y2="4"></line>
                <line x1="14" y1="1" x2="14" y2="4"></line>
              </svg>
            </div>
            <h3 className="text-[#3d3d3d] font-medium mb-2">Healthy Food</h3>
            <p className="text-sm text-[#5a5a5a] px-2">Nutritious meals for growing children</p>
          </div>

          <div className="flex flex-col items-center group">
            <div className="bg-[#d1f0f6] p-5 rounded-full mb-4 group-hover:bg-[#b3e5f8] transition-colors duration-300">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-[#3498db]"
              >
                <path d="M12 2v3"></path>
                <path d="M19.07 4.93c-1.41 1.41-2.83 2.83-4.24 4.24-.71.71-1.17 1.17-1.42 1.42a1 1 0 0 0 0 1.41l2.82 2.83a1 1 0 0 0 1.42 0c.25-.25.71-.71 1.42-1.42 1.41-1.41 2.83-2.83 4.24-4.24"></path>
                <path d="M12 15H2"></path>
                <path d="M2 12h3"></path>
                <path d="M15 12h7"></path>
              </svg>
            </div>
            <h3 className="text-[#3d3d3d] font-medium mb-2">Clean Water</h3>
            <p className="text-sm text-[#5a5a5a] px-2">Safe drinking water and sanitation</p>
          </div>

          <div className="flex flex-col items-center group">
            <div className="bg-[#fde9e9] p-5 rounded-full mb-4 group-hover:bg-[#fcd5d5] transition-colors duration-300">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-[#e74c3c]"
              >
                <path d="M4 19.5v-15A2.5 2.5 0 0 1 6.5 2H20v20H6.5a2.5 2.5 0 0 1 0-5H20"></path>
              </svg>
            </div>
            <h3 className="text-[#3d3d3d] font-medium mb-2">Education</h3>
            <p className="text-sm text-[#5a5a5a] px-2">Quality learning and school supplies</p>
          </div>

          <div className="flex flex-col items-center group">
            <div className="bg-[#d8f5f5] p-5 rounded-full mb-4 group-hover:bg-[#b8eded] transition-colors duration-300">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-[#4db6ac]"
              >
                <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z"></path>
              </svg>
            </div>
            <h3 className="text-[#3d3d3d] font-medium mb-2">Medical Care</h3>
            <p className="text-sm text-[#5a5a5a] px-2">Healthcare and medical support</p>
          </div>

          <div className="flex flex-col items-center group">
            <div className="bg-[#e8f5e9] p-5 rounded-full mb-4 group-hover:bg-[#c8e6c9] transition-colors duration-300">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-[#4caf50]"
              >
                <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
                <polyline points="9 22 9 12 15 12 15 22"></polyline>
              </svg>
            </div>
            <h3 className="text-[#3d3d3d] font-medium mb-2">Safe Shelter</h3>
            <p className="text-sm text-[#5a5a5a] px-2">Secure and loving homes</p>
          </div>

          <div className="flex flex-col items-center group">
            <div className="bg-[#e3f2fd] p-5 rounded-full mb-4 group-hover:bg-[#bbdefb] transition-colors duration-300">
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="40"
                height="40"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                strokeWidth="2"
                strokeLinecap="round"
                strokeLinejoin="round"
                className="text-[#2196f3]"
              >
                <circle cx="12" cy="12" r="10"></circle>
                <path d="M12 16v-4"></path>
                <path d="M12 8h.01"></path>
              </svg>
            </div>
            <h3 className="text-[#3d3d3d] font-medium mb-2">Counseling</h3>
            <p className="text-sm text-[#5a5a5a] px-2">Emotional support and guidance</p>
          </div>
        </div>

        <div className="mt-12 text-center">
          <Link href="/about-us#our-programs">
            <Button className="bg-[#4db6ac] hover:bg-[#3d9d93] text-white">Learn More About Our Programs</Button>
          </Link>
        </div>
      </div>
    </section>
  )
}

